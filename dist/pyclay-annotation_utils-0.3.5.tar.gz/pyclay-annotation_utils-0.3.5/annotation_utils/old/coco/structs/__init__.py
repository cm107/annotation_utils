from .coco_structs import COCO_Info, COCO_License, COCO_License_Handler, \
    COCO_Image, COCO_Image_Handler, COCO_Annotation, COCO_Annotation_Handler, \
    COCO_Category, COCO_Category_Handler