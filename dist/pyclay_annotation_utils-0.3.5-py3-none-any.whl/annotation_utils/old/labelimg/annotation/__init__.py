from .labelimg_annotation import Source, Size, BoundingBox, Rectangle, RectangleHandler, \
    LabelImgAnnotationParser, LabelImgAnnotation, LabelImgAnnotationHandler