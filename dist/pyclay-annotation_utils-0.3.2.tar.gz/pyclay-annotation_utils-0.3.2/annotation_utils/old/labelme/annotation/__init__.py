from .labelme_annotation import Shape, ShapeHandler, LabelMeAnnotationParser, \
    LabelMeAnnotation, LabelMeAnnotationHandler